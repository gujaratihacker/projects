<?php
require_once 'config.php';

if (isset($_POST['add_task'])) {
    $task = $_POST['task'];
    $sql = "INSERT INTO tasks (task) VALUES ('$task')";
    $conn->query($sql);
    header("Refresh:0");
    exit;
}

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $sql = "DELETE FROM tasks WHERE id = '$id'";
    $conn->query($sql);
    header("Refresh:0");
    exit;
}

if (isset($_GET['status'])) {
    $id = $_GET['status'];
    $status = $_GET['status_value'];
    $sql = "UPDATE tasks SET status = '$status' WHERE id = '$id'";
    $conn->query($sql);
    header("Refresh:0");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>To-Do List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .task {
            padding: 10px;
            border-bottom: 1px solid #ccc;
        }
        .completed {
            text-decoration: line-through;
        }
    </style>
</head>
<body>
    <h1>To-Do List</h1>
    <form action="" method="post">
        <input type="text" name="task" placeholder="Add new task">
        <button type="submit" name="add_task">Add</button>
    </form>
    <ul>
        <?php
        $sql = "SELECT * FROM tasks";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            ?>
            <li class="task <?php if ($row['status'] == 1) echo 'completed'; ?>">
                <?php echo $row['task']; ?>
                <a href="?delete=<?php echo $row['id']; ?>">Delete</a>
                <a href="?status=<?php echo $row['id']; ?>&status_value=<?php echo ($row['status'] == 0) ? 1 : 0; ?>">
                    <?php if ($row['status'] == 0) echo 'Mark as completed'; else echo 'Mark as incomplete'; ?>
                </a>
            </li>
            <?php
        }
        ?>
    </ul>
</body>
</html>

