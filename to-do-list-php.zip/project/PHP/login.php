<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="icon" type="image/x-icon" href="to-do-list.ico">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="form-container">
        <h1>Login</h1>
        <form action="#" method="post">
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <input type="submit" class="btn" name="submit" value="Login">
            <p class="signup-link">Don't have an account? <a href="register.html">Sign Up</a></p>
        </form>
    </div>

<?php

    $login=false;
    $showError=false;
    $server="localhost";
    $username="root";
    $pass="";
    $database="users";
        
    $con=mysqli_connect($server,$username,$pass,$database);
    if(isset($_POST['submit']))
    {
        $email=$_POST['email'];
        $password=$_POST['password'];
        
        $query ="SELECT * FROM users WHERE email='$email' AND password='$password'";
        $run=mysqli_query($con,$query);

        $num=mysqli_num_rows($run);

        if($num==1)
        {
            $login=true;
            session_start();
            $_SESSION['loggedin'] = true;
            $_SESSION['username'] = $username;
            header("location:welcome.php");

        }
        else{
            $showError="Invalid Email or Password!";
        }
        if($login)
        {
            echo "You are logged in..!";
        }
        else{
            echo "Invalid Email or Password..!";
        }   
    }
    else{
        die(mysqli_connect_error());
    }
    $con->close();
    ?>
    </body>
</html>