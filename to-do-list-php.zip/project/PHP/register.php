<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up Page</title>
    <link rel="icon" type="image/x-icon" href="to-do-list.ico">
    <link rel="stylesheet" href="style.css">
    
    
</head>
<body>
    <div class="form-container">
        <h1>Sign Up</h1>
        <form action="#" method="post">
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <input type="submit" class="btn" value="Sign Up" name="submit">
            <p class="login-link">Already have an account? <a href="login.php">Login</a></p>
        </form>
    </div>
    <?php
        $server="localhost";
        $username="root";
        $pass="";
        $database="users";

    $con=mysqli_connect($server,$username,$pass,$database);
    if(isset($_POST['submit']))
    {
        $name=$_POST['name'];
        $email=$_POST['email'];
        $password=$_POST['password'];
        
        if($email){
        $query ="INSERT INTO  users(name, email, password) VALUES('$name', '$email', '$password')";
        $run=mysqli_query($con,$query);
        echo "<script>
                window.onload = function() {
                    var alertBox = document.createElement('div');
                    alertBox.innerHTML = 'Registration successfully Now You can login..!';
                    alertBox.style.position = 'absolute';
                    
                    alertBox.style.backgroundColor = 'green';
                    alertBox.style.color = 'white';
                    alertBox.style.top = '40px'
                    alertBox.style.padding = '10px 20px';
                    alertBox.style.borderRadius = '5px';
                    alertBox.style.boxShadow = '0 0 10px rgba(0,0,0,0.1)';
                    document.body.appendChild(alertBox);

                    // Remove the alert after 3 seconds
                    setTimeout(function() {
                        alertBox.remove();
                    }, 5000);
                }
            </script>";
        }
    }
    else{
        die(mysqli_connect_error());
    }
    $con->close();
?>
</body>
</html>
