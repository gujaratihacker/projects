var dt = new Date();
document.getElementById("datetime").innerHTML = dt.toLocaleString();
