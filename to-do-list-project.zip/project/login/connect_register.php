<?php
    // $server="localhost";
    // $username="root";
    // $pass="";
    // $database="users";

    $con=mysqli_connect('localhost','root','','users');
    if(isset($_POST['submit']))
    {
        $name=$_POST['name'];
        $mail=$_POST['mail'];
        $password=$_POST['password'];

        $query ="INSERT INTO  users(name, mail, password) VALUES('$name', '$mail', '$password')";
        $run=mysqli_query($con,$query);

    }
    $con->close();
?>
</body>
</html>