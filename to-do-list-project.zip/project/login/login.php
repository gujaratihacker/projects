<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="form-container">
        <h1>Login</h1>
        <form action="#" method="post">
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <input type="submit" class="btn" name="submit" value="Login">
            <p class="signup-link">Don't have an account? <a href="register.html">Sign Up</a></p>
        </form>
    </div>
</body>
</html>

<?php
session_start(); // Start session to handle user login

$servername = "localhost"; // Database server
$db_username = "root"; // Database username
$db_password = ""; // Database password
$dbname = "users"; // Database name

// Create connection
$conn = new mysqli($servername, $db_username, $db_password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if(isset($_POST['submit']))
    {
        $email=$_POST['email'];
        $password=$_POST['password'];
        
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Fetch user data
        $user = $result->fetch_assoc();
    
        // Verify password
        if (password_verify($password, $user['password']) && ($_SESSION['email']==$user['email'])) {
            echo "Login successful! Welcome, " . $_SESSION['email'] . ".";
        } else {
            echo "Invalid password. Please try again.";
        }
    } else {
        echo "User not found. Please sign up.";
    }
    
    $stmt->close();
    $conn->close();
}
    ?>